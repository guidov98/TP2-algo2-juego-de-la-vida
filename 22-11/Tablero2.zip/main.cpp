
#include "JuegoDeLaVida.h"

using namespace std;



int main(){
    srand(time(NULL));

    bienvenida();

	Configuraciones configuracion = (Configuraciones)elegirConfiguracion();

	//JuegoDeLaVida juego(configuracion);
    Decision decision = Continuar;
    JuegoDeLaVida *juego= new JuegoDeLaVida(configuracion);

    cout << "El tablero inicial es el siguiente: " << endl;
    juego->mostrarTablero();

    while(decision != Salir){
        decision =  juego->pedirDecision();

        if(decision == Continuar){
            int cantidadDeTurnos = juego->preguntarCantidadDeTurnos();
            for(int i = 0; i < cantidadDeTurnos; i++){
                juego->getTablero()->actualizarTablero(juego->getX1(), juego->getX2(), juego->getX3());
                juego->mostrarTablero();
            }
            
        }/*
        else if(decision == Reiniciar){
            //reiniciar juego de la vida 
        }*/
    }

    delete juego;
    return 0;
}